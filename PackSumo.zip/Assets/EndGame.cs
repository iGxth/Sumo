using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EndGame : MonoBehaviour
{

    public string targetSceneName; // ���ͧ͢�չ����ͧ����

    void OnTriggerEnter2D(Collider2D other)
    {
        // ��Ǩ�ͺ��Ҫ��� Player �������
        if (other.CompareTag("Player"))
        {
            SceneManager.LoadScene(targetSceneName);
        }
    }


    public void GotoMainMenu()
    {
        SceneManager.LoadScene("Menu");
    }


    public void Restart()
    {
        SceneManager.LoadScene("Bootstrap");
    }

}


