using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Netcode;

public class Eatting : NetworkBehaviour
{

    

    public int playerSpeed;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }



    /*private void OnTriggerEnter2D(Collider2D foods)
    {
        if (foods.CompareTag("Player"))
        {
            PlayerMovement playerMovement = foods.GetComponent<PlayerMovement>();
            if (playerMovement != null)
            {
                playerMovement.movementSpeed += 5;
            }

            Destroy(gameObject)
        }
    }*/
}


