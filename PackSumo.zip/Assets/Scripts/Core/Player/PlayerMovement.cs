using System.Collections;
using System.Collections.Generic;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMovement : NetworkBehaviour
{
    [Header("References")]
    [SerializeField] private InputReader inputReader;
    [SerializeField] private Transform bodyTransform;
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private ParticleSystem dustCloud;

    [Header("Settings")]
    [SerializeField] private float movementSpeed = 4f;
    [SerializeField] private float turningRate = 30f;
    [SerializeField] private float partocleEmissionValue = 10f;
    private ParticleSystem.EmissionModule emissionModule;

    private Vector2 previousMovementInput;
    private Vector3 previousPos;

    private const float ParticleStopThreshold = 0.005f;
    private void Awake()
    {
        emissionModule = dustCloud.emission;
    }
    public override void OnNetworkSpawn()
    {
        if (!IsOwner) { return; }
        inputReader.MoveEvent += HandleMove;
    }
    public override void OnNetworkDespawn()
    {
        if(!IsOwner) { return; }
        inputReader.MoveEvent -= HandleMove;
    }
    // Update is called once per frame
    void Update()
    {
        if(!IsOwner) { return ; }

        float zRotation = previousMovementInput.x * -turningRate * Time.deltaTime;
        bodyTransform.Rotate(0f,0f,zRotation);



    }

    private void FixedUpdate()
    {
        if ((transform.position - previousPos).sqrMagnitude > ParticleStopThreshold)
        {
            emissionModule.rateOverTime = partocleEmissionValue;
        }
        else
        {
            emissionModule.rateOverTime = 0;
        }
        previousPos = transform.position;

        if (!IsOwner) { return ; }

        rb.velocity = (Vector2)bodyTransform.up * previousMovementInput.y * movementSpeed;
    }

    private void HandleMove(Vector2 movementInput)
    {
        previousMovementInput = movementInput;
    }

    private void OnTriggerEnter2D(Collider2D eat)
    {
        if (eat.CompareTag("Coin"))
        {
            PlayerMovement playerMovement = eat.GetComponent<PlayerMovement>();
           movementSpeed += 5;

            StartCoroutine(ReduceSpeed(playerMovement, 1.0f));

          
        }

        /*else if (eat.CompareTag("Lose"))
        {
            SceneManager.LoadScene("EndGame");
        }*/
    }

    private IEnumerator ReduceSpeed(PlayerMovement playerMovement , float delay)
    {
        yield return new WaitForSeconds(delay);
        playerMovement.movementSpeed =  5f;
    }
}
