using System;

[Serializable]
public class UserData
{
    public string userName;
    public string userAuthId;
    public int userColorIndex;
}
